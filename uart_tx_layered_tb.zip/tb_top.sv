`timescale 1ns/1ps
import uart_tb_pkg::*;

module tb_top;
    parameter CLKS_PER_BIT = 16;
    logic clk = 0;

    // 100 MHz Clock Generation
    always #5 clk = ~clk;

    // Interface & DUT Instantiation
    uart_if #(CLKS_PER_BIT) vif(clk);

    uart_tx #(
        .CLKS_PER_BIT(CLKS_PER_BIT)
    ) dut (
        .clk         (clk),
        .rst_n       (vif.rst_n),
        .tx_start    (vif.tx_start),
        .tx_data     (vif.tx_data),
        .parity_en   (vif.parity_en),
        .parity_type (vif.parity_type),
        .tx_serial   (vif.tx_serial),
        .tx_busy     (vif.tx_busy)
    );

    // Optional: SystemVerilog Assertion (SVA) for extra credit
    property p_busy_during_tx;
        @(posedge clk) disable iff (!vif.rst_n)
        $rose(vif.tx_start) |=> vif.tx_busy;
    endproperty
    assert property (p_busy_during_tx) else $error("SVA Error: tx_busy did not assert!");

    // Test Execution
    uart_env #(CLKS_PER_BIT) env;

    initial begin
        // Dump waveforms for EPWave / GTKWave / Questa
        $dumpfile("uart_tx.vcd");
        $dumpvars(0, tb_top);

        // Apply Reset
        vif.rst_n = 0;
        repeat (5) @(posedge clk);
        vif.rst_n = 1;

        // Run 40 randomized transactions
        env = new(vif, 40);
        env.run();
        $finish;
    end
endmodule
