# UART Transmitter - SystemVerilog Class-Based Layered Testbench

## Files Included
1. `uart_tx.sv` - Parameterized UART Transmitter RTL design supporting configurable parity (None, Even, Odd).
2. `uart_if.sv` - SystemVerilog Interface with driver and monitor clocking blocks.
3. `uart_tb_pkg.sv` - Verification package containing Transaction, Generator, Driver, Monitor, Scoreboard (with Functional Coverage), and Environment classes.
4. `tb_top.sv` - Top-level testbench module with clock/reset generation, DUT instantiation, and SystemVerilog Assertions (SVA).

## Compilation Order
Compile the files in the exact dependency order below:
```bash
vlog uart_tx.sv uart_if.sv uart_tb_pkg.sv tb_top.sv
vsim -c tb_top -do "run -all; quit"
```

For VCS:
```bash
vcs -sverilog uart_tx.sv uart_if.sv uart_tb_pkg.sv tb_top.sv -R
```

For Vivado XSIM:
```bash
xvlog -sv uart_tx.sv uart_if.sv uart_tb_pkg.sv tb_top.sv
xelab tb_top -s sim_top
xsim sim_top -runall
```
