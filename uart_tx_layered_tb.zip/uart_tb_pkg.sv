package uart_tb_pkg;

    // ---------------------------------------------------------
    // 1. TRANSACTION CLASS
    // ---------------------------------------------------------
    class uart_txn;
        rand logic [7:0] data;
        rand logic       parity_en;
        rand logic       parity_type; // 0 = Even, 1 = Odd

        // Observed fields captured by Monitor
        logic            obs_parity;
        logic            obs_stop;

        // Constraint to hit corner cases (0x00, 0xFF) along with random bytes
        constraint data_dist_c {
            data dist { 8'h00 := 10, 8'hFF := 10, [8'h01:8'hFE] := 80 };
        }

        function void display(string tag = "");
            $display("[%0t] [%s] Data=0x%0h | Parity_En=%0b | Parity_Type=%s",
                     $time, tag, data, parity_en, parity_type ? "ODD" : "EVEN");
        endfunction
    endclass

    // ---------------------------------------------------------
    // 2. GENERATOR CLASS
    // ---------------------------------------------------------
    class uart_generator;
        mailbox #(uart_txn) gen2drv;
        mailbox #(uart_txn) gen2scb;
        int num_txns;
        event drv_done;

        function new(mailbox #(uart_txn) gen2drv, mailbox #(uart_txn) gen2scb, int num_txns);
            this.gen2drv  = gen2drv;
            this.gen2scb  = gen2scb;
            this.num_txns = num_txns;
        endfunction

        task run();
            uart_txn txn;
            repeat (num_txns) begin
                txn = new();
                assert(txn.randomize()) else $fatal("Randomization failed!");
                txn.display("GEN");
                gen2drv.put(txn);
                gen2scb.put(txn);
                @(drv_done); // Wait for driver to finish current frame
            end
        endtask
    endclass

    // ---------------------------------------------------------
    // 3. DRIVER CLASS
    // ---------------------------------------------------------
    class uart_driver;
        virtual uart_if vif;
        mailbox #(uart_txn) gen2drv;
        event drv_done;

        function new(virtual uart_if vif, mailbox #(uart_txn) gen2drv, event drv_done);
            this.vif      = vif;
            this.gen2drv  = gen2drv;
            this.drv_done = drv_done;
        endfunction

        task run();
            uart_txn txn;
            vif.drv_cb.tx_start    <= 1'b0;
            vif.drv_cb.tx_data     <= 8'h00;
            vif.drv_cb.parity_en   <= 1'b0;
            vif.drv_cb.parity_type <= 1'b0;

            wait(vif.rst_n === 1'b1);

            forever begin
                gen2drv.get(txn);
                @(vif.drv_cb);
                vif.drv_cb.tx_data     <= txn.data;
                vif.drv_cb.parity_en   <= txn.parity_en;
                vif.drv_cb.parity_type <= txn.parity_type;
                vif.drv_cb.tx_start    <= 1'b1;

                @(vif.drv_cb);
                vif.drv_cb.tx_start    <= 1'b0;

                // Wait until DUT finishes transmitting the frame
                wait(vif.drv_cb.tx_busy === 1'b1);
                wait(vif.drv_cb.tx_busy === 1'b0);
                -> drv_done;
            end
        endtask
    endclass

    // ---------------------------------------------------------
    // 4. MONITOR CLASS (Serial-to-Parallel Receiver Model)
    // ---------------------------------------------------------
    class uart_monitor #(parameter CLKS_PER_BIT = 16);
        virtual uart_if vif;
        mailbox #(uart_txn) mon2scb;

        function new(virtual uart_if vif, mailbox #(uart_txn) mon2scb);
            this.vif     = vif;
            this.mon2scb = mon2scb;
        endfunction

        task run();
            uart_txn txn;
            wait(vif.rst_n === 1'b1);

            forever begin
                // Detect Start Bit falling edge
                @(negedge vif.mon_cb.tx_serial);
                txn = new();
                txn.parity_en   = vif.mon_cb.parity_en;
                txn.parity_type = vif.mon_cb.parity_type;

                // Move to the middle of the Start Bit
                repeat (CLKS_PER_BIT / 2) @(vif.mon_cb);
                if (vif.mon_cb.tx_serial !== 1'b0)
                    $error("[%0t] [MON] False Start Bit detected!", $time);

                // Sample 8 Data Bits at the center of each baud period
                for (int i = 0; i < 8; i++) begin
                    repeat (CLKS_PER_BIT) @(vif.mon_cb);
                    txn.data[i] = vif.mon_cb.tx_serial;
                end

                // Sample Parity Bit if enabled
                if (txn.parity_en) begin
                    repeat (CLKS_PER_BIT) @(vif.mon_cb);
                    txn.obs_parity = vif.mon_cb.tx_serial;
                end

                // Sample Stop Bit
                repeat (CLKS_PER_BIT) @(vif.mon_cb);
                txn.obs_stop = vif.mon_cb.tx_serial;

                txn.display("MON");
                mon2scb.put(txn);
            end
        endtask
    endclass

    // ---------------------------------------------------------
    // 5. SCOREBOARD & FUNCTIONAL COVERAGE CLASS
    // ---------------------------------------------------------
    class uart_scoreboard;
        mailbox #(uart_txn) gen2scb;
        mailbox #(uart_txn) mon2scb;
        int pass_cnt = 0;
        int fail_cnt = 0;
        uart_txn cov_txn;

        // Functional Coverage Group
        covergroup uart_cg;
            cp_data: coverpoint cov_txn.data {
                bins zero     = {8'h00};
                bins all_ones = {8'hFF};
                bins low      = {[8'h01:8'h7F]};
                bins high     = {[8'h80:8'hFE]};
            }
            cp_parity_en:   coverpoint cov_txn.parity_en;
            cp_parity_type: coverpoint cov_txn.parity_type iff (cov_txn.parity_en);
            cross_cfg:      cross cp_data, cp_parity_en, cp_parity_type;
        endgroup

        function new(mailbox #(uart_txn) gen2scb, mailbox #(uart_txn) mon2scb);
            this.gen2scb = gen2scb;
            this.mon2scb = mon2scb;
            uart_cg      = new();
        endfunction

        task run();
            uart_txn exp_txn, act_txn;
            logic exp_parity;

            forever begin
                gen2scb.get(exp_txn);
                mon2scb.get(act_txn);

                // Sample Functional Coverage
                cov_txn = exp_txn;
                uart_cg.sample();

                // Calculate Expected Parity
                exp_parity = exp_txn.parity_type ? ~(^exp_txn.data) : (^exp_txn.data);

                // Verify Data, Parity, and Stop Bit
                if (act_txn.data !== exp_txn.data) begin
                    $error("[SCB] DATA MISMATCH! Exp: 0x%0h, Act: 0x%0h", exp_txn.data, act_txn.data);
                    fail_cnt++;
                end else if (exp_txn.parity_en && (act_txn.obs_parity !== exp_parity)) begin
                    $error("[SCB] PARITY MISMATCH! Exp: %0b, Act: %0b", exp_parity, act_txn.obs_parity);
                    fail_cnt++;
                end else if (act_txn.obs_stop !== 1'b1) begin
                    $error("[SCB] STOP BIT ERROR! Expected 1, got %0b", act_txn.obs_stop);
                    fail_cnt++;
                end else begin
                    $display("[SCB] PASS -> Data=0x%0h verified successfully.", act_txn.data);
                    pass_cnt++;
                end
            end
        endtask

        function void report();
            $display("\n========================================");
            $display("        UART VERIFICATION SUMMARY       ");
            $display("========================================");
            $display(" Total Passed        : %0d", pass_cnt);
            $display(" Total Failed        : %0d", fail_cnt);
            $display(" Functional Coverage : %0.2f%%", uart_cg.get_inst_coverage());
            $display("========================================\n");
        endfunction
    endclass

    // ---------------------------------------------------------
    // 6. ENVIRONMENT CLASS
    // ---------------------------------------------------------
    class uart_env #(parameter CLKS_PER_BIT = 16);
        uart_generator               gen;
        uart_driver                  drv;
        uart_monitor #(CLKS_PER_BIT) mon;
        uart_scoreboard              scb;

        mailbox #(uart_txn) gen2drv;
        mailbox #(uart_txn) gen2scb;
        mailbox #(uart_txn) mon2scb;
        event drv_done;
        virtual uart_if vif;

        function new(virtual uart_if vif, int num_txns = 30);
            this.vif = vif;
            gen2drv  = new();
            gen2scb  = new();
            mon2scb  = new();

            gen = new(gen2drv, gen2scb, num_txns);
            drv = new(vif, gen2drv, drv_done);
            mon = new(vif, mon2scb);
            scb = new(gen2scb, mon2scb);
        endfunction

        task run();
            fork
                gen.run();
                drv.run();
                mon.run();
                scb.run();
            join_any
            #500; // Allow final transaction to drain
            scb.report();
        endtask
    endclass

endpackage
