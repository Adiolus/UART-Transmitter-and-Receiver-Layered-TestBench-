interface uart_if #(parameter CLKS_PER_BIT = 16) (input logic clk);
    logic       rst_n;
    logic       tx_start;
    logic [7:0] tx_data;
    logic       parity_en;
    logic       parity_type;
    logic       tx_serial;
    logic       tx_busy;

    clocking drv_cb @(posedge clk);
        default input #1step output #1ns;
        output tx_start, tx_data, parity_en, parity_type;
        input  tx_busy;
    endclocking

    clocking mon_cb @(posedge clk);
        default input #1step;
        input tx_serial, tx_busy, parity_en, parity_type;
    endclocking
endinterface
