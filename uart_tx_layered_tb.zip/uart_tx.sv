module uart_tx #(
    parameter CLKS_PER_BIT = 16 // Keep small (e.g., 16) for fast simulation
)(
    input  logic       clk,
    input  logic       rst_n,
    input  logic       tx_start,
    input  logic [7:0] tx_data,
    input  logic       parity_en,   // 1: Enable parity, 0: No parity
    input  logic       parity_type, // 0: Even parity, 1: Odd parity
    output logic       tx_serial,
    output logic       tx_busy
);

    typedef enum logic [2:0] {
        IDLE   = 3'b000,
        START  = 3'b001,
        DATA   = 3'b010,
        PARITY = 3'b011,
        STOP   = 3'b100
    } state_t;

    state_t state;
    logic [$clog2(CLKS_PER_BIT)-1:0] clk_cnt;
    logic [2:0] bit_idx;
    logic [7:0] data_reg;
    logic       parity_bit;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state      <= IDLE;
            tx_serial  <= 1'b1; // Idle line is HIGH
            tx_busy    <= 1'b0;
            clk_cnt    <= '0;
            bit_idx    <= '0;
            data_reg   <= '0;
            parity_bit <= 1'b0;
        end else begin
            case (state)
                IDLE: begin
                    tx_serial <= 1'b1;
                    clk_cnt   <= '0;
                    bit_idx   <= '0;
                    if (tx_start) begin
                        tx_busy    <= 1'b1;
                        data_reg   <= tx_data;
                        parity_bit <= parity_type ? ~(^tx_data) : (^tx_data);
                        state      <= START;
                    end else begin
                        tx_busy <= 1'b0;
                    end
                end

                START: begin
                    tx_serial <= 1'b0; // Start bit is LOW
                    if (clk_cnt < CLKS_PER_BIT - 1) begin
                        clk_cnt <= clk_cnt + 1;
                    end else begin
                        clk_cnt <= '0;
                        state   <= DATA;
                    end
                end

                DATA: begin
                    tx_serial <= data_reg[bit_idx];
                    if (clk_cnt < CLKS_PER_BIT - 1) begin
                        clk_cnt <= clk_cnt + 1;
                    end else begin
                        clk_cnt <= '0;
                        if (bit_idx < 7) begin
                            bit_idx <= bit_idx + 1;
                        end else begin
                            bit_idx <= '0;
                            state   <= parity_en ? PARITY : STOP;
                        end
                    end
                end

                PARITY: begin
                    tx_serial <= parity_bit;
                    if (clk_cnt < CLKS_PER_BIT - 1) begin
                        clk_cnt <= clk_cnt + 1;
                    end else begin
                        clk_cnt <= '0;
                        state   <= STOP;
                    end
                end

                STOP: begin
                    tx_serial <= 1'b1; // Stop bit is HIGH
                    if (clk_cnt < CLKS_PER_BIT - 1) begin
                        clk_cnt <= clk_cnt + 1;
                    end else begin
                        clk_cnt <= '0;
                        tx_busy <= 1'b0;
                        state   <= IDLE;
                    end
                end

                default: state <= IDLE;
            endcase
        end
    end
endmodule
